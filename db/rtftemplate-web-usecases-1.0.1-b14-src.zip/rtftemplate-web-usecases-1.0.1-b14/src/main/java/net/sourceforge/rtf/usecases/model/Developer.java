package net.sourceforge.rtf.usecases.model;

import java.util.ArrayList;
import java.util.Collection;

/**
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class Developer {

	private String name;
	private String email;
	private Collection roles;
	private Manager manager;
	
	public Developer(String name, String email) {
		this.name = name;
		this.email = email;
		roles = new ArrayList();
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Collection getRoles() {
		return roles;
	}
	public void setRoles(Collection roles) {
		this.roles = roles;
	}
	public void addRole(Role role) {
		roles.add(role);
	}
	public void addRole(String roleName) {
		addRole(new Role(roleName));
	}

	public Manager getManager() {
		return manager;
	}

	public void setManager(Manager manager) {
		this.manager = manager;
	}
	
}
