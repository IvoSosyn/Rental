package net.sourceforge.rtf.usecases.model;

import java.io.InputStream;

/**
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class Project {

	private String name;
	private InputStream logo = null;
	
	public Project(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void setLogo(InputStream logo)  {
		this.logo = logo;
	}
	
	public InputStream getLogo()  {
		return logo;
	}
}
