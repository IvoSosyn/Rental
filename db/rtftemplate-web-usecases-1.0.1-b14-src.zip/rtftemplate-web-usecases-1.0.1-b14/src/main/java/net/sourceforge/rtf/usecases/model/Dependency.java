package net.sourceforge.rtf.usecases.model;

/**
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class Dependency {

	private String artifactID;
	private String type;
	private String version;
	private String url;
	
	public Dependency(String artifactID, String type, String version, String url) {
		this.artifactID = artifactID;
		this.type = type;
		this.version = version;
		this.url = url;
	}
	
	public String getArtifactID() {
		return artifactID;
	}
	public void setArtifactID(String artifactID) {
		this.artifactID = artifactID;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
}
