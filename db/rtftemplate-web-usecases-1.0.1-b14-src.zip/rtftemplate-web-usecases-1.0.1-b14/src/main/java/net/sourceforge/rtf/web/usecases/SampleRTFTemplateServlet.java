package net.sourceforge.rtf.web.usecases;

import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import net.sourceforge.rtf.template.IContext;
import net.sourceforge.rtf.usecases.model.Dependency;
import net.sourceforge.rtf.usecases.model.Developer;
import net.sourceforge.rtf.usecases.model.Project;
import net.sourceforge.rtf.web.servlet.AbstractRTFTemplateServlet;

/**
 * 
 * Sample RTFTemplate Servlet which implements RTFTemplateServlet.
 * 
 * @version 1.0.0 
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 *
 */
public class SampleRTFTemplateServlet extends AbstractRTFTemplateServlet  {
	
	public static final long serialVersionUID = 1L;	
	private static final String JAKARATA_VELOCITY_MODEL = "jakarta-velocity-model";
    private static final String REQUEST_MODELNAME = "modelName";
    private static final String REQUEST_MUSTBECACHED = "mustBeCached";
	
	protected Reader getRTFReader(HttpServletRequest request) throws Exception {
		// 1. Get Real path of RTF model.
		String rtfModelName = request.getParameter(REQUEST_MODELNAME);
		rtfModelName+= ".rtf";
		String rtfModelPath = "/models/jakartavelocityproject/" + rtfModelName; 
		rtfModelPath = super.getRealPathOfRTFModel(request, rtfModelPath);
		
		// 2. Get Reader of RTF model
		Reader rtfModelReader = new FileReader(new File(rtfModelPath));
		return rtfModelReader;
	}
	
    protected String cacheWithKey(HttpServletRequest request) {
        // Test if checkbox cache is checked
        if (request.getParameter(REQUEST_MUSTBECACHED) != null) {
            // Cache must be enable for the RTF model
            // return name of the RTF model
            return request.getParameter(REQUEST_MODELNAME);
        }
        return null;
    }
    
    protected String unCacheWithKey(HttpServletRequest request) {
        // Test if checkbox cache is checked
        if (request.getParameter(REQUEST_MUSTBECACHED) == null) {
            // Cache must be disable for the RTF model
            // return name of the RTF model
            return request.getParameter(REQUEST_MODELNAME);            
        }        
        return null;
    }
    
	protected void putContext(HttpServletRequest request, IContext ctx ) throws Exception {
		// Swith RTF Model Name, Context is different
		String rtfModelName = request.getParameter(REQUEST_MODELNAME);
		if (JAKARATA_VELOCITY_MODEL.equals(rtfModelName)) {
			putContextJAKARATA_VELOCITY_MODEL(request, ctx);
		}
		else {
			// ...... Other RTF model
		}
	}
	
	protected InputStream getXMLFieldsAvailable(HttpServletRequest request) throws Exception {
		//	Swith RTF Model Name, XML fields available is different or can be null
		String rtfModelName = request.getParameter(REQUEST_MODELNAME);
		if (JAKARATA_VELOCITY_MODEL.equals(rtfModelName)) {
			String xmlFieldsAvailable = rtfModelName + ".fields.xml";
			InputStream inputStream = SampleRTFTemplateServlet.class.getResourceAsStream(xmlFieldsAvailable);
			return inputStream;
		}
		else {
			// ...... Other RTF model
		}
		return null;
	}
	
	protected void putContextJAKARATA_VELOCITY_MODEL(HttpServletRequest request, IContext ctx ) throws Exception {
		
		String projectName = request.getParameter("projectName");
		/*
		 * Context of simply POJO
		 */
		ctx.put("date", new Date());
		ctx.put("project", new Project(projectName));
		
		ctx.put("header_developer_name", "Name");
		ctx.put("header_developer_email", "Email");
		ctx.put("header_developer_roles", "Roles");
		/*
		 * Context of list of POJO (Developers and Dependencies)
		 */
        List developers = new ArrayList();
        Developer developer = new Developer("Will Glass-Husain", "wglass@apache.org");
        developer.addRole("Java Developer");
        developer.addRole("Release Manager");
        developers.add(developer);
        developer = new Developer("Geir Magnusson Jr.", "geirm@apache.org");
        developer.addRole("Java Developer");
        developer.addRole("Release Manager");
        developers.add(developer);
        developer = new Developer("Daniel L. Rall", "dlr@finemaltcoding.comg");
        developer.addRole("Java Developer");
        developer.addRole("Release Manager");
        developers.add(developer);
        ctx.put("developers", developers );
        
        List dependencies = new ArrayList();
        Dependency dependency = new Dependency("commons-collection", "jar", "1.0", "http://jakarta.apache.org/commons/collection/");
        dependencies.add(dependency);
        dependency = new Dependency("logkit", "jar", "1.0.1", "http://logkit");
        dependencies.add(dependency);
        dependency = new Dependency("oro", "jar", "2.0.8", "http://jakarta.apache.org/oro/");
        dependencies.add(dependency);
        
        ctx.put("dependencies", dependencies );		
	}
	
	/**
	 * return name of FileName for Content-Disposition
	 */
	protected String getFileNameOfContentDisposition(HttpServletRequest request) {
		String rtfModelName = request.getParameter(REQUEST_MODELNAME);
		if (rtfModelName != null) {
			return rtfModelName + ".rtf";
		}
		return super.getFileNameOfContentDisposition(request);
	}
    
}
