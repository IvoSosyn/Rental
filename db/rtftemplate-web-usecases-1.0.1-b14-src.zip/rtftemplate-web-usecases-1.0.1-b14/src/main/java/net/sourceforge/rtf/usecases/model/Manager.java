package net.sourceforge.rtf.usecases.model;

import java.util.ArrayList;
import java.util.List;

public class Manager {

	private List projects;
	
	public Manager(String name) {
		this.name = name;
		this.projects = new ArrayList();
	}
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void addProject(Project project) {
		projects.add(project);
	}
	
	public List getProjects() {
		return projects;
	}
	
	
}
