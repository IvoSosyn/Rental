package net.sourceforge.rtf.usecases.model;

public class DeveloperGroup {


	private Developer developer1;
	private Developer developer2;
	private Developer developer3;

	public DeveloperGroup(Developer developer1, Developer developer2, Developer developer3 ) {
		this.developer1 = developer1;
		this.developer2 = developer2;
		this.developer3 = developer3;
	}
	
	public Developer getDeveloper1() {
		return developer1;
	}
	public void setDeveloper1(Developer developer1) {
		this.developer1 = developer1;
	}
	public Developer getDeveloper2() {
		return developer2;
	}
	public void setDeveloper2(Developer developer2) {
		this.developer2 = developer2;
	}
	public Developer getDeveloper3() {
		return developer3;
	}
	public void setDeveloper3(Developer developer3) {
		this.developer3 = developer3;
	}
	
	
}
