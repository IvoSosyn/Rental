package net.sourceforge.rtf.usecases.model;

import java.util.ArrayList;
import java.util.List;

public class Workspace {

	private Workspace parentWorkspace;
	
	private Project projectCurrent;
	
	private List othersProject;
	private List developers;
	
	public Workspace() {
		this.developers = new ArrayList();
	}
	public List getOthersProject() {
		return othersProject;
	}

	public void setOthersProject(List othersProject) {
		this.othersProject = othersProject;
	}

	public Project getProjectCurrent() {
		return projectCurrent;
	}

	public void setProjectCurrent(Project projectCurrent) {
		this.projectCurrent = projectCurrent;
	}

	public Workspace getParentWorkspace() {
		return parentWorkspace;
	}

	public void setParentWorkspace(Workspace parentWorkspace) {
		this.parentWorkspace = parentWorkspace;
	}
	
	public void addDeveloper(Developer developer) {
		this.developers.add(developer);
	}
	public List getDevelopers() {
		return developers;
	}
	
	
	
}
