--------
RTFTemplate
--------

Welcome to RTFTemplate. RTFTemplate is a general purpose RTF template engine
written in Java. For more information about RTFTemplate, please look at the
as the RTFTemplate web site

  http://rtftemplate.sourceforge.net/index.html

This archive contains RTFTemplate usecases.

Here is a description of what each of the top level directories
contains. Please consult the documentation in each of the lower level
directories for information that is specific to their contents.

bat/      This is bat files to execute each use cases. 
          To execute it, open Command Windows, set to directory bat, and execute bat.
          After executing bat, directory RTF files target are generated into 
          usecases/out/...
lib/      This is libraries required for RTFTEmplate use cases (RTFTEmplate, Velocity...).
src/      This is where all of the source code to RTFTEmplate Usecases lives.
usecases/ This is RTF models source used for use cases (directory models). 
          Directory out contains RTF files target generated.

REQUIREMENTS
------------

The Java 2 SDK is required to build RTFTemplate.


INCLUDED PRE-BUILT JARS
-----------------------
If you are using an offical RTFTemplate release distribution, 
you will find pre-built RTFTemplate jars in the top level 
directory.

PLEASE NOTE : 1.0 is the RTFTemplate release version.

rtftemplate-usecases<version>.jar : RTFTemplate Usecases jar.


-The RTFTemplate Team
