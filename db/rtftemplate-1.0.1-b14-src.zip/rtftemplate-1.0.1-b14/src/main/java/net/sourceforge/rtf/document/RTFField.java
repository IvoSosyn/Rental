package net.sourceforge.rtf.document;

/**
 * RTF element field
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class RTFField extends RTFElement {

    public final static int FIELDTYPE_UNKNOW = 0;

    public final static int FIELDTYPE_MERGEFIELD = 1;

    public final static int FIELDTYPE_HYPERLINK = 2;

    public final static int FIELDTYPE_FORMTEXT = 3;

    public final static int FIELDTYPE_REF = 4;

    private String name = null;

    private int type; // MERGEFIELD OR HYPERLINK

    private String condition = null; // JUST FOR REF field type

    public RTFField() {
        this.type = FIELDTYPE_UNKNOW;
    }

    public RTFField(RTFField field) {
        super(field);
    }

    public String getName() {
        if (name == null) {
            String rtfContent = getRTFContentOfSimpleElement();
            if (rtfContent != null) {
                // Test if field id MERGEFIELD (name bettewen MERGEFIELD and \)
                name = getElementTextBetween(rtfContent, "MERGEFIELD", "\\");
                if (name != null) {
                    type = FIELDTYPE_MERGEFIELD;
                } else {
                    // Test if field id HYPERLINK (name bettewen HYPERLINK and
                    // "}
                    name = getElementTextBetween(rtfContent, "HYPERLINK", "\\");
                    if (name != null) {
                        name = name.replaceAll("mailto:", "");
                        type = FIELDTYPE_HYPERLINK;
                    } else {
                        // Test if field id FORMTEXT (name bettewen ffdeftext
                        // and "}
                        if (rtfContent.indexOf("FORMTEXT") != -1) {
                            name = getElementTextBetween(rtfContent,
                                    "\\ffdeftext", "}");
                            type = FIELDTYPE_FORMTEXT;
                        } else {
                            String content = getElementTextBetween(rtfContent,
                                    " REF ", "}");
                            if (content != null) {
                                int spaceIndex = content.indexOf(" ");
                                if (spaceIndex != -1) {
                                    name = content.substring(0, spaceIndex);
                                    condition = content.substring(
                                            spaceIndex + 1, content.length());
                                    type = FIELDTYPE_REF;
                                }
                            }
                        }
                    }
                }
                if (name != null) {
                    name = name.replaceAll("\"", "");
                    name = name.replaceAll("\\}", "");
                    name = name.replaceAll("\\{", "");
                    name = name.trim();
                }
            }
        }
        return name;
    }

    public int getType() {
        if (type == -1) {
            getName();
        }
        return type;
    }

    public String getCondition() {
        return condition;
    }

}
