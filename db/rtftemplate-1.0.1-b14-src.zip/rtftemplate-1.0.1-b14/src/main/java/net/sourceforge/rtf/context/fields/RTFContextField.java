package net.sourceforge.rtf.context.fields;

/**
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class RTFContextField {

	private boolean list;
	private String listInfo;
	private boolean image;
	private String name = null;
	
	private String description = null;
	
	public RTFContextField() {
		
	}
	
	
	public RTFContextField(String name, boolean list, String listInfo) {
		this.name = name;
		this.list = list;
		this.listInfo = listInfo;
	}
	
	public RTFContextField(String name) {
		this(name, false, "");
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public boolean isList() {
		return list;
	}
	public void setList(boolean list) {
		this.list = list;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isImage() {
		return image;
	}
	
	public void setImage(boolean image) {
		this.image = image;
	}

	public String getListInfo() {
		return listInfo;
	}


	public void setListInfo(String listInfo) {
		this.listInfo = listInfo;
	}
	
	
	
}
