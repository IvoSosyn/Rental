package net.sourceforge.rtf.helper.test;

import java.io.StringReader;
import java.io.StringWriter;

import net.sourceforge.rtf.ITemplateEngine;
import net.sourceforge.rtf.helper.RTFTemplateBuilder;

public class TestFreemarkerEngine {

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {
            /**
             * 1. Get RTFtemplate builder
             */
            RTFTemplateBuilder builder = RTFTemplateBuilder.newRTFTemplateBuilder();
            
            /**
             * 2. Get freemarker engine
             */ 
            ITemplateEngine freemarkerEngine = 
                builder.newTemplateEngine(RTFTemplateBuilder.FREEMARKER_ENGINE);
            
            /**
             * 3. Set the template
             */ 
            StringReader template = new StringReader("Today : ${date}");
            freemarkerEngine.setTemplate(template);            
            
            /**
             * 4. Put context
             */
            freemarkerEngine.put("date", "12/02/2007");
            
            /**
             * 5. Merge context with template
             */ 
            StringWriter writer = new StringWriter();
            freemarkerEngine.merge(writer);
            
            // => Result of merge
            System.out.println(writer.getBuffer());
        }
        catch(Exception e) {
            System.out.println("Error");
            e.printStackTrace();
        }
    }

}
