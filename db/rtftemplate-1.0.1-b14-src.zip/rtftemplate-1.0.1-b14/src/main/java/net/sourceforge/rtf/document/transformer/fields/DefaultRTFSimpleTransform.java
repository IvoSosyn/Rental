package net.sourceforge.rtf.document.transformer.fields;

import net.sourceforge.rtf.document.RTFField;

public class DefaultRTFSimpleTransform implements IRTFFieldTransform {

	public void transform(RTFField field, boolean fieldIsList, IRTFFieldNameTransform fieldNameTransform) {
		field.replaceElement(field.getName());
	}

}
