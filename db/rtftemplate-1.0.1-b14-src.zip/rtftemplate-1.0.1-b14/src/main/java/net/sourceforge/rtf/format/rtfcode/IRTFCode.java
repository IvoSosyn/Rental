package net.sourceforge.rtf.format.rtfcode;

/**
 * Interface for manage RTF code.
 * 
 * @version 1.0.1-b11
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 *
 */
public interface IRTFCode {

	/**
	 * Return true if content must be escaped 
	 * (replace '{' character with "\{" and '}' with "\}") 
	 * @return
	 */
	public boolean isEscaped();
	
	/**
	 * Return RTF content.
	 * @return
	 */
	public String getContent();
	
}
