package net.sourceforge.rtf;

import java.io.File;
import java.io.Reader;
import java.io.Writer;
import java.text.Format;

import net.sourceforge.rtf.template.IContext;

public interface ITemplateEngine {

    /**
     * Initialize context.
     * must be called if the same instance 
     * of template engine must be used for merge 
     * serveral RTF template model.
     */
    public IContext initializeContext();
    
    public IContext getContext();
    
	/**
	 * Set the template to use
	 * 
	 * @param template
	 */
	public void setTemplate(Reader template);
	
    /**
     * Put a value for the given key.
     *
     * @param key
     * @param value
     */
    public void put(String key, Object value);
    
    /**
     * Merge.
     *
     * @param file name of file to merge into
     */
    public void merge(String file) throws Exception;    
    
    /**
     * Merge.
     *
     * @param file    file to merge into
     */
    public void merge(File file) throws Exception;
    
    /**
     * Merge.
     *
     * @param writer    writer to merge into
     */
    public void merge(Writer writer) throws Exception;    
    
    /**
     * 
     * @return
     */
    public IContext newContext();
    
    /**
     * Use a pre-populated Context.
     * This method treats any previously populated keys in the context kindly,
     * so it won't act unpredictably if this is called late
     *
     * @param innerContext  a pre-populated Context object
     */
    public void setGlobalContext( IContext globalContext);
    
    /**
     * Set the default format for a given class.
     *
     * @param clazz   class to set format for
     * @param format  format to use for instances of the given class
     */
    public void setDefaultFormat(Class clazz, Format format);    
}
