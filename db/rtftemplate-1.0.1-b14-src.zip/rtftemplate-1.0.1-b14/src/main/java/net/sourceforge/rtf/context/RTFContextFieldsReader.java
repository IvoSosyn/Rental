package net.sourceforge.rtf.context;

import net.sourceforge.rtf.context.fields.RTFContextBookmark;
import net.sourceforge.rtf.context.fields.RTFContextFields;
import net.sourceforge.rtf.context.fields.RTFContextField;

/**
 * Implement AbstractRTFContextReader to Read velocity context
 * and populate RTFContextFields class with all keys putted
 * into Velocity Context.
 *  
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class RTFContextFieldsReader extends AbstractRTFContextReader {

	private RTFContextFields fields;
	protected void startReading() {
		fields = new RTFContextFields();
		
	}
	
	protected void endReading() {
		
	}
	
	/**
	 * Add field
	 */
	protected void addMergeField(String mergeFieldName, boolean mergeFieldIsList, String mergeFieldNameWithListInfo, boolean isImage) {
		RTFContextField field = new RTFContextField(mergeFieldName, mergeFieldIsList, mergeFieldNameWithListInfo);
		field.setImage(isImage);
		fields.addMergeField(field);
	}
	
	public RTFContextFields getContextFields() {
		return fields;
	}
	
	/**
	 * Add Bookmark
	 */
	protected void addBookmark(String bookmarkName, String type) {
		RTFContextBookmark bookmark = new RTFContextBookmark(bookmarkName, type);
		fields.addBookmark(bookmark);
	}
	
}
