package net.sourceforge.rtf.format.rtfcode;

/**
 * 
 * RTF code string implements IRTFCode
 * 
 * @version 1.0.11 
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 *
 */
public class RTFCodeString implements IRTFCode  {

    private String content;
    private boolean escaped;
    
    public RTFCodeString(String content) {
        this(content, false);
    }
    
    public RTFCodeString(String content, boolean escaped) {
    	this.content = content;
    	this.escaped = escaped;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

	public boolean isEscaped() {
		return escaped;
	}

	public void setEscaped(boolean escaped) {
		this.escaped = escaped;
	}

    
}
