package net.sourceforge.rtf.template.velocity;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.context.Context;

import net.sourceforge.rtf.template.IContext;

public class VelocityContextImpl extends VelocityContext implements IContext {
	
	public static final long serialVersionUID = 1L;
	private IContext globalContext;
    
    public VelocityContextImpl( )
    {
        super();
    }

    /**
     *  Chaining constructor,
     *
     *  @param innerContext context impl to wrap
     */
    public VelocityContextImpl(Context innerContext )
    {
        super( innerContext );
    }
        
    /**
     * Overridden so that the <code>null</code> values are accepted.
     *
     * @see   AbstractVelocityContext#put(String,Object)
     */
    public Object put(String key, Object value)
    {
        if (key == null)
        {
            return null;
        }
        return internalPut(key, value);
    }
    
    public IContext getGlobalContext() {
        if (globalContext == null) {
            globalContext = new VelocityContextImpl(super.getChainedContext());
        }
        return globalContext;
    }
}
