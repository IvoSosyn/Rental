package net.sourceforge.rtf;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

import net.sourceforge.rtf.document.RTFDocument;

/**
 * Interface for parse RTF source and build a RTFDocument.
 * 
 * @version 1.0.1-b8 
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 *
 */
public interface IRTFDocumentParser {
    
    /**
     * Parse RTF Reader stream and build a RTFDocumen
     * @param reader RTF source reader to parse.
     * @throws IOException
     */
    public void parse(Reader reader) throws IOException;

    /**
     * Parse RTF Input stream and build a RTFDocument.
     * @param input stream RTF source reader to parse.
     * @throws IOException
     */
    public void parse(InputStream inputStream) throws IOException;
    
    /**
     * Return RTFDocument built.
     * @return
     */
    public RTFDocument getRTFDocument();    
}
