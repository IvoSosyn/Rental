package net.sourceforge.rtf.document;

import java.util.Vector;

/**
 * Base RTF Element. 
 * RTF element is composed by list <b>elementList</b> of : 
 * <ul>
 * 	<li>rtf string code.</li>
 * 	<li>others RTF element.</li>
 * </ul>
 * Order of element list <b>elementList</b> follow order of Document RTF parsed.  
 * 
 * @see net.sourceforge.rtf.document.RTFDocument
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 */
public class RTFElement  {
	
	private Vector elementList = null;
	private StringBuffer currentRTFString = null;
	private RTFElement rtfElementParent = null;
	
	private String firstRTFString = null;
	private String lastRTFString = null;
	
	public RTFElement() {
		this.elementList = new Vector();
	}
	
    /**
     * remove the current RTF string of the this if it is not null - meaning the
     * last in the element list is a StrigBuffer, not an RTF element. 
     * 
     * @return the removed element
     */ 
    public StringBuffer removeCurrentRTFString() {
        //no exception
        if (currentRTFString == null) return new StringBuffer();
        
        elementList.remove(currentRTFString);
        StringBuffer ret = currentRTFString;
        currentRTFString = null;
        return ret;
    }
    
	public RTFElement(RTFElement element) {
		// Clone RTF element vector
		this.elementList =  (Vector)(element.elementList.clone());
	}
	
	public void addRTFElement(RTFElement element) {
		currentRTFString = null;
		element.setRtfElementParent(this);
		elementList.add(element);
	}
	
	public void addRTFString(String rtfContent) {
		if (currentRTFString == null) {
			currentRTFString = new StringBuffer();
			elementList.add(currentRTFString);
		}
		currentRTFString.append(rtfContent);
	}
	
	public void flush() {
		if (firstRTFString != null) {
			elementList.add(0, new StringBuffer(firstRTFString));
			firstRTFString = null;
		}
		if (lastRTFString != null) {
			elementList.add(new StringBuffer(lastRTFString));
			lastRTFString = null;
		}
	}
	
	public String getFirstRTFString() {
		return this.firstRTFString;
	}
	
	public void addFirstRTFString(String rtfContent) {
		this.firstRTFString = rtfContent;
	}
	
	public void addLastRTFString(String rtfContent) {
		this.lastRTFString = rtfContent;
	}

	public Vector getElementList() {
		return elementList;
	}

	public RTFElement getRtfElementParent() {
		return rtfElementParent;
	}

	public void setRtfElementParent(RTFElement rtfElementParent) {
		this.rtfElementParent = rtfElementParent;
	}
	
	/**
	 * Replace element of RTFElement by String <content>
	 * @param content
	 */
	public void replaceElement(String content) {
		this.elementList = new Vector();
		currentRTFString = null;
		addRTFString(content);
	}
	
	/**
	 * Retourne le code RTF d'un element RTF simple,
	 * autrement dit qui ne contient pas d'autres element RTF
	 * (ex : Champs..)
	 * @return
	 */
	public String getRTFContentOfSimpleElement() {
		Vector elementList = getElementList();
		if (elementList != null && elementList.size() == 1) {
			StringBuffer rtfContent = (StringBuffer)elementList.get(0);
			if (rtfContent != null) {
				String content = rtfContent.toString();
				content = content.replaceAll("\r", "");
				content = content.replaceAll("\n", "");
				return content;
			}
		}
		return null;
	}
	
	public String getRTFFirstContentOfElement() {
		Vector elementList = getElementList();
		if (elementList != null && elementList.size() > 0) {
			StringBuffer rtfContent = (StringBuffer)elementList.get(0);
			if (rtfContent != null) {
				String content = rtfContent.toString();
				content = content.replaceAll("\r", "");
				content = content.replaceAll("\n", "");
				return content;
			}
		}
		return  null;
	}
	
	/**
	 * Retourne la chaine comprise entre startToken et endToken
	 * du contenu RTF rtfContent.
	 * @param rtfContent
	 * @param startToken
	 * @param endToken
	 * @return
	 */
	protected String getElementTextBetween(String rtfContent, String startToken, String endToken) {
		if (rtfContent != null) {
			// Replace all \n
			String content = rtfContent;
			int indexStartToken = content.indexOf(startToken);
			int indexEndToken = content.indexOf(endToken, indexStartToken);
			if (indexStartToken != -1 && indexEndToken != -1) {
				indexStartToken += startToken.length();
				return content.substring(indexStartToken, indexEndToken).trim();
			}
		}
		return null;
	}
}
