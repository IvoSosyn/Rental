package net.sourceforge.rtf.helper.test;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Date;

import net.sourceforge.rtf.ITemplateEngine;
import net.sourceforge.rtf.helper.RTFTemplateBuilder;

public class TestVelocityEngine {

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {
            /**
             * 1. Get RTFtemplate builder
             */
            RTFTemplateBuilder builder = RTFTemplateBuilder.newRTFTemplateBuilder();
            
            /**
             * 2. Get velocity engine
             */ 
            ITemplateEngine velocityEngine = 
                builder.newTemplateEngine(RTFTemplateBuilder.VELOCITY_ENGINE);
            
            /**
             * 3. Set the template
             */ 
            StringReader template = new StringReader("Today : ${date}");
            velocityEngine.setTemplate(template);            
            
            /**
             * 4. Put context
             */
            velocityEngine.put("date", new Date());
            
            /**
             * 5. Merge context with template
             */ 
            StringWriter writer = new StringWriter();
            velocityEngine.merge(writer);
            
            // => Result of merge
            System.out.println(writer.getBuffer());
        }
        catch(Exception e) {
            System.out.println("Error");
            e.printStackTrace();
        }
    }

}
