package net.sourceforge.rtf.document.transformer.fields;

import net.sourceforge.rtf.document.RTFField;

/**
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public interface IRTFFieldTransform {

	public void transform(RTFField field, boolean fieldIsList, IRTFFieldNameTransform fieldNameTransform);
}
