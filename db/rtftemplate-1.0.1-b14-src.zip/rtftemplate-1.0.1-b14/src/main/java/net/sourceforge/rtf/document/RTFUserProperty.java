package net.sourceforge.rtf.document;

/**
 * RTF User property
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 *
 */
public class RTFUserProperty extends RTFElement {

	private String name = null;
	private String value = null;
	
	public String getName () {
		if (name == null) {
			String rtfContent = getRTFContentOfSimpleElement();
			rtfContent = rtfContent.replaceAll("\r", "");
			rtfContent = rtfContent.replaceAll("\n", "");
			if (rtfContent != null) {
				// Name is beetween \propname and }
				name =  getElementTextBetween(rtfContent , "\\propname", "}");
			}
		}
		return name;
	}

	public String getValue() {
		if (value == null) {
			String rtfContent = getRTFContentOfSimpleElement();
			rtfContent = rtfContent.replaceAll("\r", "");
			rtfContent = rtfContent.replaceAll("\n", "");
			if (rtfContent != null) {
				// Value is beetween \propname and }
				value =  getElementTextBetween(rtfContent , "\\staticval", "}");
			}
		}
		return value;
	}
	
}
