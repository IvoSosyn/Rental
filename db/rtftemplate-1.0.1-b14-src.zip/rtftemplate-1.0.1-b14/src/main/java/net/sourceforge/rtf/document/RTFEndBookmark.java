package net.sourceforge.rtf.document;

public class RTFEndBookmark extends RTFBookmark {

	public RTFEndBookmark() {
		super("bkmkend");
	}
}
