package net.sourceforge.rtf.document;

/**
 * RTF element page break. This element contains one StringBuffer
 * (see elementList of RTFElement) with RTF code <b>\page</b>. 
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 */
public class RTFPage extends RTFElement {

}
