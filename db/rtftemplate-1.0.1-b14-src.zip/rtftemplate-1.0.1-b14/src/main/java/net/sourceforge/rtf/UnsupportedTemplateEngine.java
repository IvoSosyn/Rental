package net.sourceforge.rtf;

public class UnsupportedTemplateEngine extends Exception  {

    public static final long serialVersionUID = 1L;
    private String templateEngineType;
    
    public UnsupportedTemplateEngine(String templateEngineType) {
        super("RTFTemplate can't support template engine type : " + templateEngineType);
        this.templateEngineType = templateEngineType;
    }
    
    public String getTemplateEngineType() {
        return this.templateEngineType;
    }
}
