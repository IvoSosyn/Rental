package net.sourceforge.rtf.document.transformer.fields;

public interface IRTFFieldNameTransform {
       
    public String getTransformedFieldName(boolean fieldIsList, String fieldName);
}
