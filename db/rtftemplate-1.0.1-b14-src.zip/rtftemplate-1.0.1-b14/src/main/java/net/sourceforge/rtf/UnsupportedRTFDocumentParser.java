package net.sourceforge.rtf;

public class UnsupportedRTFDocumentParser extends Exception {

    public static final long serialVersionUID = 1L;
    private String rtfDocumentParserType;
    
    public UnsupportedRTFDocumentParser(String rtfDocumentParserType) {
        super("RTFTemplate can't support rtf document transformer type : " + rtfDocumentParserType);
        this.rtfDocumentParserType = rtfDocumentParserType;
    }
    
    public String getRTFDocumentParserType() {
        return this.rtfDocumentParserType;
    }

}

