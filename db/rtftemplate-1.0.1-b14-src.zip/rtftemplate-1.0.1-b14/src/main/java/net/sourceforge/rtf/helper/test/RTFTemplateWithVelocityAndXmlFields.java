package net.sourceforge.rtf.helper.test;

import java.io.InputStream;
import java.io.StringWriter;
import java.util.Date;

import net.sourceforge.rtf.RTFTemplate;
import net.sourceforge.rtf.helper.RTFTemplateBuilder;

public class RTFTemplateWithVelocityAndXmlFields {

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {
            /**
             * 1. Get RTFtemplate builder
             */
            RTFTemplateBuilder builder = RTFTemplateBuilder.newRTFTemplateBuilder();
            
            /**
             * 2. Get RTFtemplate with Velocity Implementation
             */ 
            RTFTemplate rtfTemplate = builder.
                newRTFTemplate(RTFTemplateBuilder.DEFAULT_VELOCITY_RTFTEMPLATE);
            
            /**
             * Load XML fields available and set it to the RTFTemplate
             */
            InputStream xmlFieldsStream = RTFTemplateWithVelocityAndXmlFields.class.getResourceAsStream("test.fields.xml");
            rtfTemplate.setXmlFields(xmlFieldsStream);
            
            /**
             * 3. Set the template
             */ 
            String rtfSourceModel = "test.rtf";
            InputStream inputStream = TestFreemarkerTransformer.class.getResourceAsStream(rtfSourceModel);
            rtfTemplate.setTemplate(inputStream);
            
            /**
             * 4. Put context
             */ 
            rtfTemplate.put("date", new Date());
            
            /**
             * 5. Merge context with template
             * In this case context will be used to transform RTFDocument
             */  
            StringWriter writer = new StringWriter();
            rtfTemplate.merge(writer);
            
            // => Result of merge
            System.out.println(writer.getBuffer());                        
            
        }
        catch (Exception e) {
            System.out.println("Error:");
            e.printStackTrace();
        }

    }

}
