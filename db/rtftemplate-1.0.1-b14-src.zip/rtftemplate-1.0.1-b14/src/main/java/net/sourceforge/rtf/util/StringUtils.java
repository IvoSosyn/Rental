package net.sourceforge.rtf.util;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class StringUtils {

    public static final String sub(String line, String oldString, String newString)
    {
        int i = 0;
        if((i = line.indexOf(oldString, i)) >= 0)
        {
            char line2[] = line.toCharArray();
            char newString2[] = newString.toCharArray();
            int oLength = oldString.length();
            StringBuffer buf = new StringBuffer(line2.length);
            buf.append(line2, 0, i).append(newString2);
            i += oLength;
            int j;
            for(j = i; (i = line.indexOf(oldString, i)) > 0; j = i)
            {
                buf.append(line2, j, i - j).append(newString2);
                i += oLength;
            }

            buf.append(line2, j, line2.length - j);
            return buf.toString();
        } else
        {
            return line;
        }
    }
    
    public static String[] split(String line, String delim)
    {
        List list = new ArrayList();
        for(StringTokenizer t = new StringTokenizer(line, delim); t.hasMoreTokens(); list.add(t.nextToken()));
        return (String[])list.toArray(new String[list.size()]);
    }    

}
