package net.sourceforge.rtf;

public class UnsupportedRTFTemplate extends Exception {

    public static final long serialVersionUID = 1L;
    private String rtfTemplateType;
    
    public UnsupportedRTFTemplate(String rtfTemplateType) {
        super("RTFTemplate can't support rtf rtf template type : " + rtfTemplateType);
        this.rtfTemplateType = rtfTemplateType;
    }
    
    public String getRTFTemplateTypeType() {
        return this.rtfTemplateType;
    }
 
}
