package net.sourceforge.rtf.context.fields;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class RTFContextFields {

	private String description = null;
	private List mergeFields = null;
	private Map mergeFieldsMap = null;
	private List bookmarks = null;
	private Map bookmarksMap = null;
	
	public RTFContextFields() {
		this.mergeFields = new ArrayList();
		this.bookmarks = new ArrayList();
	}

	public void addMergeField(RTFContextField mergeField) {
		mergeFields.add(mergeField);
	}
	
	public List getMergeFields() {
		return mergeFields;
	}
	
	public Map getMergeFieldsMap() {
		if (mergeFieldsMap == null) {
			mergeFieldsMap = new HashMap();
			// Construct map with list of mergefield context fields
			for (Iterator iter = getMergeFields().iterator(); iter.hasNext();) {
				RTFContextField element = (RTFContextField) iter.next();
				mergeFieldsMap.put(element.getName(), element);
			}
		}
		return mergeFieldsMap;
	}
	
	public void addBookmark(RTFContextBookmark bookmark) {
		bookmarks.add(bookmark);
	}
	
	public List getBookmarks() {
		return bookmarks;
	}
	
	public Map getBookmarksMap() {
		if (bookmarksMap == null) {
			bookmarksMap = new HashMap();
			// Construct map with list of Bookmark context fields
			for (Iterator iter = getBookmarks().iterator(); iter.hasNext();) {
				RTFContextBookmark element = (RTFContextBookmark) iter.next();
				bookmarksMap.put(element.getType(), element);
			}
		}
		return bookmarksMap;
	}
	
	
	public void toXml(String filename) throws FileNotFoundException {
		toXml(new File(filename));

	}
	
	public void toXml(File filePath) throws FileNotFoundException{
		PrintStream p= new PrintStream(new FileOutputStream(filePath, false));
    	p.println("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>");
    	p.println("<fields>");
    	
    	// Description of model
    	String fieldsDescription = this.getDescription();
    	if (fieldsDescription == null)
    		fieldsDescription = "";
    	p.println("\t<description><![CDATA[" + fieldsDescription + "]]></description>");
    	// Loop for bookmark
    	for (Iterator iter = getBookmarks().iterator(); iter.hasNext();) {
    		RTFContextBookmark element = (RTFContextBookmark) iter.next();
    		toXml(p, element);
    	}
    	// Loop for mergefield
    	for (Iterator iter = getMergeFields().iterator(); iter.hasNext();) {
    		RTFContextField element = (RTFContextField) iter.next();
    		toXml(p, element);
    	}
    	p.println("</fields>");
    	p.flush();
	    p.close();
	}
	
	private void toXml(PrintStream p, RTFContextBookmark bookmark) {
		String bookmarkType = bookmark.getType();
		String bookmarkName = bookmark.getName();
		String bookmarkDescription = bookmark.getDescription();
		if (bookmarkDescription == null)
			bookmarkDescription = "";
		p.println("\t<bookmark>");
		p.println("\t\t<type>" + bookmarkType + "</type>");
		p.println("\t\t<name>" + bookmarkName + "</name>");
		p.println("\t\t<description><![CDATA[" + bookmarkDescription + "]]></description>");
		p.println("\t</bookmark>");
	}
	
	private void toXml(PrintStream p, RTFContextField field) {
		boolean isMergeFieldList = field.isList();
		String listInfo = field.getListInfo();
		String mergeFieldName = field.getName();
		String mergeFieldDescription = field.getDescription();
		if (mergeFieldDescription == null)
			mergeFieldDescription = "";
		p.println("\t<mergefield>");
		p.println("\t\t<list>" + String.valueOf(isMergeFieldList) + "</list>");
		p.println("\t\t<listInfo>" + listInfo + "</listInfo>");
		p.println("\t\t<name>" + mergeFieldName + "</name>");
		p.println("\t\t<description><![CDATA[" + mergeFieldDescription + "]]></description>");
		p.println("\t</mergefield>");
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
