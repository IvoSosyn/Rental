package net.sourceforge.rtf.template;

public interface IContext {
	
    /**
     * Put a value for the given key.
     *  
     * @param key
     * @param value
     * @return
     */
    public Object put(String key, Object value);
    
    /** Get the value of the given key.
	 *
	 * @param key
	*/
    public Object get(String key);
    
    /**
     * 
     * @return
     */
    public Object[] getKeys();
    
    public IContext getGlobalContext();
    
   
}
