package net.sourceforge.rtf.context.fields;

/**
 * RTF context bookmark is composed by : 
 * <ul>
 * 	<li><b>type</b> for manage start loop (START_LOOP)
 *  and end loop (END_LOOP).
 * 	</li>
 *  <li><b>name</b> of bookmark start/end loop (because RTF bookmark
 *  are unique into RTF). Name is pattern used into RTF model for
 *  start/end loop (eg : START_LOOP_{i} and END_LOOP_{i}) 
 * 	</li>
 *  <li><b>description</b> of type bookmark (which be used by MS
 *  MACRO Word). 
 * 	</li>
 * </ul>
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class RTFContextBookmark {

	private String type; 
	private String name = null;
	private String description = null;
	
	public RTFContextBookmark() {
		
	}
	
	public RTFContextBookmark(String name, String type) {
		this.name = name;
		this.type = type;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
