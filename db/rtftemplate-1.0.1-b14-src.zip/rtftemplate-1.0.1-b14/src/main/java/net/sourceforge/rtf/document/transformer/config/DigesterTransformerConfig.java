package net.sourceforge.rtf.document.transformer.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.digester.Digester;
import org.xml.sax.SAXException;

/**
 * Digester for loading XML transformer config
 * and create JAVA object TransformerConfig.
 * Here XML file transform-config example :  
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class DigesterTransformerConfig {

	private static final String DEFAULT_XML_TRANSFORMER_CONFIG = "transformer-config.xml";  

	/**
	 * Load XML <b>transformer-config.xml</b> and return TransformerConfig.
	 * @return TransformerConfig
	 * @throws SAXException
	 * @throws IOException
	 */
	public static TransformerConfig getTransformerConfig() throws SAXException, IOException {
		InputStream inputStream =  DigesterTransformerConfig.class.getResourceAsStream(DEFAULT_XML_TRANSFORMER_CONFIG);
		return getTransformerConfig(inputStream);
	}
	
	/**
	 * Load XML configFileName file name  and return TransformerConfig.
	 * @param configFileName
	 * @return TransformerConfig
	 * @throws SAXException
	 * @throws IOException
	 */
	public static TransformerConfig getTransformerConfig(String configFileName) throws SAXException, IOException {
		return getTransformerConfig(new File(configFileName));
	}
	
	/**
	 * Load XML configFileName file and return TransformerConfig.
	 * @param configFile
	 * @return TransformerConfig
	 * @throws SAXException
	 * @throws IOException
	 */
	public static TransformerConfig getTransformerConfig(File configFile) throws SAXException, IOException {
		return getTransformerConfig(new FileInputStream(configFile));
	}
	
	
	/**
	 * Load XML configFileName file and return TransformerConfig.
	 * @param inputStream
	 * @return TransformerConfig
	 * @throws SAXException
	 * @throws IOException
	 */
	public static TransformerConfig getTransformerConfig(InputStream inputStream) throws SAXException, IOException {
		Digester digester = new Digester();
        digester.setValidating( false );
        digester.addObjectCreate( "transformer-config", TransformerConfig.class );
        digester.addBeanPropertySetter( "transformer-config/bookmark-start-loop/pattern", "bookmarkStartLoopPattern" );
        digester.addBeanPropertySetter( "transformer-config/bookmark-end-loop/pattern", "bookmarkEndLoopPattern" );
        digester.addBeanPropertySetter( "transformer-config/bookmark-if/pattern", "bookmarkIfPattern" );
        digester.addBeanPropertySetter( "transformer-config/bookmark-end-if/pattern", "bookmarkEndIfPattern" );   
        digester.addBeanPropertySetter( "transformer-config/bookmark-else/pattern", "bookmarkElsePattern" );        
        return (TransformerConfig)digester.parse( inputStream );
	}
	
	/**
	 * Test for loading TransformerConfig with digester. 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			TransformerConfig transformerConfig = DigesterTransformerConfig.getTransformerConfig();
			System.out.println("BookmarkStartLoopPattern : "  + transformerConfig.getBookmarkStartLoopPattern());
			System.out.println("BookmarkEndLoopPattern : "  + transformerConfig.getBookmarkEndLoopPattern());
		}
		catch (Exception e) {
			System.out.println("Error while digester transformer config : " + e.getMessage());
		}
		
	}
}
