package net.sourceforge.rtf.template.freemarker;

import java.util.HashMap;
import java.util.Set;

import net.sourceforge.rtf.template.IContext;

public class FreemarkerContextImpl extends HashMap implements IContext {

	public static final long serialVersionUID = 1L;
	
	public Object put(String key, Object value) {
		return super.put(key, value);
	}

	public Object get(String key) {
		return super.get(key);
	}
    
    public Object[] getKeys() {
        Set keySet = super.keySet();
        if (keySet != null)
            return super.keySet().toArray();
        return null;
    }
    
    public IContext getGlobalContext() {
        return null;
    }
}
