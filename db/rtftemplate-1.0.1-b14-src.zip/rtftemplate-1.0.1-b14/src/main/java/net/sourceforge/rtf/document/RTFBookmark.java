package net.sourceforge.rtf.document;

/**
 * RTF Element Bookmark. This element contains one StringBuffer
 * (see elementList of RTFElement) for the RTF code. 
 * eg : RTF code Bookmark with name MY_BOOKMARK  :   
 * {\*\bkmkstart MY_BOOKMARK }{\*\bkmkend MY_BOOKMARK }
 * 
 * After transformation (see RTFVelocityTransformer) Bookmark loop 
 * is replaced by #foreach ($item_myList in $myList) velocity.
 * $item_myList is the velocity name list.
 * 
 * @see net.sourceforge.rtf.template.velocity.RTFVelocityTransformerImpl
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 *
 */
public abstract class RTFBookmark extends RTFElement {

	private String name = null; // Bookmark name (ex : MY_BOOKMARK)
	private String itemNameList = null; // Bokkmark name (ex : $item_myList)
    private String bkmkey = null;
    
	public RTFBookmark(String bkmkey) {
		this.name = null;
		this.itemNameList = null;
		this.bkmkey = bkmkey;
	}
	
	public RTFBookmark(RTFBookmark bookmark) {
		super(bookmark);
	}
	
	/**
	 * Return name of Bookmark.
	 * eg : for RTF code bookmark {\*\bkmkstart MY_BOOKMARK }{\*\bkmkend MY_BOOKMARK }
	 * this getter return MY_BOOKMARK.
	 * @return
	 */
	public String getName() {
		if (name == null) { 
			String rtfContent = getRTFFirstContentOfElement();
			if (rtfContent != null) {
				// Bookmark name is after bkmkstart => {\*\bkmkstart MERGEFIELD et }
				name = getElementTextBetween(rtfContent, bkmkey, "}");
			}
		}
		return name;
	}
	
	/**
	 * Return velocity name list (eg : $item_myList)
	 * @return velocity name list.
	 */
	public String getItemNameList() {
		return itemNameList;
	}

	/**
	 * Set velocity name list (eg : $item_myList)
	 * @param velocityNameList
	 */
	public void setItemNameList(String velocityNameList) {
		this.itemNameList = velocityNameList;
	}
	

	

}
