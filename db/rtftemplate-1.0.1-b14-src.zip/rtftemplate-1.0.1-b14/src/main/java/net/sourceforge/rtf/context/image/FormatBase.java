package net.sourceforge.rtf.context.image;

public class FormatBase {

	/**
     * Determines whether the image is in the according format.
     *
     * @param data Image
     *
     * @return
     * true    If according type\n
     * false   Other type
     */
    public static boolean isFormat(byte[] data) {
        return false;
    }
    
    /**
     * Convert image data if necessary - for example when format is not supported by rtf.
     *
     * @param data Image
     * @param type Format type
     */
    public FormatBase convert(FormatBase format, byte[] data) {
        return format;
    }
    
    /**
     * Determine image file format.
     *
     * @param data Image
     *
     * @return Image format class
     */

    public static FormatBase determineFormat(byte[] data) {

        if (FormatPNG.isFormat(data)) {
            return new FormatPNG();
        } else if (FormatJPG.isFormat(data)) {
            return new FormatJPG();
        } else if (FormatEMF.isFormat(data)) {
            return new FormatEMF();
        } else if (FormatGIF.isFormat(data)) {
            return new FormatGIF();
        } else if (FormatBMP.isFormat(data)) {
            return new FormatBMP();
        } else {
            return null;
        }
    }
    
    /**
     * Get image type.
     *
     * @return Image format class
     */
    public int getType() {
        return ImageConstants.I_NOT_SUPPORTED;
    }
    
    /**
     * Get rtf tag.
     *
     * @return Rtf tag for image format.
     */
    public String getRtfTag() {
        return "";
    }


	private static class FormatGIF extends FormatBase {
	    public static boolean isFormat(byte[] data) {
	        // Indentifier "GIF8" on position 0
	        byte [] pattern = new byte [] {(byte) 0x47, (byte) 0x49, (byte) 0x46, (byte) 0x38};
	
	        return ImageUtil.compareHexValues(pattern, data, 0, true);
	    }
	    
	    public int getType() {
	        return ImageConstants.I_GIF;
	    }
	}

	private static class FormatEMF extends FormatBase {
	    public static boolean isFormat(byte[] data) {
	        // No offical Indentifier known
	        byte [] pattern = new byte [] {(byte) 0x01, (byte) 0x00, (byte) 0x00};
	
	        return ImageUtil.compareHexValues(pattern, data, 0, true);
	    }
	    
	    public int getType() {
	        return ImageConstants.I_EMF;
	    }
	    
	    public String getRtfTag() {
	        return "emfblip";
	    }
	}

	private  static class FormatBMP extends FormatBase {
	    public static boolean isFormat(byte[] data) {
	        byte [] pattern = new byte [] {(byte) 0x42, (byte) 0x4D};
	
	        return ImageUtil.compareHexValues(pattern, data, 0, true);
	    }
	    
	    public int getType() {
	        return ImageConstants.I_BMP;
	    }
	}

	private static class FormatJPG extends FormatBase {
	    public static boolean isFormat(byte[] data) {
	        // Indentifier "0xFFD8" on position 0
	        byte [] pattern = new byte [] {(byte) 0xFF, (byte) 0xD8};
	
	        return ImageUtil.compareHexValues(pattern, data, 0, true);
	    }
	  
	    public int getType() {
	        return ImageConstants.I_JPG;
	    }
    
	    public String getRtfTag() {
	        return "jpegblip";
	    }
	}

	private static class FormatPNG extends FormatBase {
	    public static boolean isFormat(byte[] data) {
	        // Indentifier "PNG" on position 1
	        byte [] pattern = new byte [] {(byte) 0x50, (byte) 0x4E, (byte) 0x47};
	
	        return ImageUtil.compareHexValues(pattern, data, 1, true);
	    }
	    
	    public int getType() {
	        return ImageConstants.I_PNG;
	    }
	    
	    public String getRtfTag() {
	        return "pngblip";
	    }
	}

}
