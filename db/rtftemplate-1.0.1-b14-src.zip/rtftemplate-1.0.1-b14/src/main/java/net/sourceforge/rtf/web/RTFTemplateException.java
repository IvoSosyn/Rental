package net.sourceforge.rtf.web;

/**
 * RTFTemplate Exception used by RTFTemplateServlet..
 * @author Angelo
 *
 */
public class RTFTemplateException extends Exception {

	public static final long serialVersionUID = 1L;
	
	public RTFTemplateException(String message) {
		super(message);
	}
}
