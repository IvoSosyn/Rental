package net.sourceforge.rtf.usecases;

import java.io.File;
import java.io.FileReader;

import net.sourceforge.rtf.ITemplateEngine;
import net.sourceforge.rtf.helper.RTFTemplateBuilder;
import net.sourceforge.rtf.template.IContext;

public abstract class AbstractTemplateEngineUseCase {

    private String rtfTemplateConfig;
    private String templateEngineType;
    private String outDirectory = null;
    
    public AbstractTemplateEngineUseCase() {
        this.templateEngineType = RTFTemplateBuilder.VELOCITY_ENGINE;
    }
    
    public AbstractTemplateEngineUseCase(String outDirectory) {
        this.outDirectory = outDirectory;
    }
    
    public void run(String modelSource) throws Exception {
        File modelSourceFile = new File(modelSource);

        String modelOutput = modelSource + "." + getTemplateEngineType() + ".out";
        if (outDirectory != null) {
            // Create out Directory
            File out = new File(outDirectory);
            out.mkdirs();                       
            modelOutput = outDirectory + "/" + modelSourceFile.getName() + "." + getTemplateEngineType() + ".out.rtf";
        }
        
        /**
         * 1. Get RTFtemplate builder
         */
        RTFTemplateBuilder builder = null;
        if (rtfTemplateConfig == null)
            builder = RTFTemplateBuilder.newRTFTemplateBuilder();
        else 
            builder = RTFTemplateBuilder.newRTFTemplateBuilder(rtfTemplateConfig);
        
        /**
         * 2. Get template engine
         */
        ITemplateEngine templateEngine = 
            builder.newTemplateEngine(getTemplateEngineType());
        
        /**
         * 3. Set the template
         */ 
        templateEngine.setTemplate(new FileReader(modelSourceFile));
        
        /**
         * 4. Put Context
         */        
        IContext context = templateEngine.initializeContext();        
        putContext(context);   
                
        /**
         * 5. Merge model and context
         */
        templateEngine.merge(modelOutput);   
                
    }

    public String getTemplateEngineType() {
        if (templateEngineType == null) {
            /**
             * Default Template engine is Velocity
             */
            this.templateEngineType = RTFTemplateBuilder.VELOCITY_ENGINE;
        }
        return templateEngineType;
    }

    public void setTemplateEngineType(String templateEngineType) {
        this.templateEngineType = templateEngineType;
    }
    
    /**
     * This method must be implement by class
     * wich manage your model. 
     * Put the context of your model
     * (eg : templateEngine.put("date", new Date()); ) 
     * @param context IContext
     */
    protected abstract void putContext(IContext context);

    protected String getRtfTemplateConfig() {
        return rtfTemplateConfig;
    }

    protected void setRtfTemplateConfig(String rtfTemplateConfig) {
        this.rtfTemplateConfig = rtfTemplateConfig;
    }
    
    

}
