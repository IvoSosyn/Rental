package net.sourceforge.rtf.template.freemarker;

import java.io.Writer;

import net.sourceforge.rtf.template.AbstractTemplateEngine;
import net.sourceforge.rtf.template.IContext;
import freemarker.template.Configuration;
import freemarker.template.Template;

public class FreemarkerTemplateEngineImpl extends AbstractTemplateEngine {

    private Configuration freemarkerConfiguration = null;

	protected void mergeWithTemplateEngine(Writer writer) throws Exception {
		Template template  = new Template("rtfModel", super.template,  freemarkerConfiguration);		
		template.process(super.getContext(), writer);			
	}
	
	public Configuration getFreemarkerConfiguration() {
		return freemarkerConfiguration;
	}

	public void setFreemarkerConfiguration(Configuration freemarkerConfiguration) {
		this.freemarkerConfiguration = freemarkerConfiguration;
	}
	
    public IContext newContext() {
		return new FreemarkerContextImpl();
	}	
	
}
