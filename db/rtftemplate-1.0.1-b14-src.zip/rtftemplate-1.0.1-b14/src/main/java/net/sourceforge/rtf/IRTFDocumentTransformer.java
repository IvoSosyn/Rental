package net.sourceforge.rtf;

import java.io.IOException;

import net.sourceforge.rtf.context.fields.RTFContextFields;
import net.sourceforge.rtf.document.RTFDocument;
import net.sourceforge.rtf.document.transformer.config.TransformerConfig;
import net.sourceforge.rtf.template.IContext;

/**
 * Interface for transform RTFDocument. 
 * 
 * @version 1.0.1-b8
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public interface IRTFDocumentTransformer {

    public void setTransformerConfig(TransformerConfig transformerConfig);
    
    public int getGroupByPerPageBreak();
    public void setGroupByPerPageBreak(int groupByPerPageBreak);
    
    public void setCircularReferences(boolean circularReferences);
    public boolean isCircularReferences();
    
    public RTFDocument transform(RTFDocument document, IContext context) throws IOException;
    public RTFDocument transform(RTFDocument document, RTFContextFields contextFields) throws IOException;
    

}
