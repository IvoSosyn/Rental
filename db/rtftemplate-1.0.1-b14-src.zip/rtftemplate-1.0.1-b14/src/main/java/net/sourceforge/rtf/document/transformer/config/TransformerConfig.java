package net.sourceforge.rtf.document.transformer.config;

/**
 * This class manage Pattern used for :
 * <ul>
 * <li> Bookmark START_LOOP pattern (eg : START_LOOP_{i}). {i} defined the i th
 * bookmark start loop(eg : START_LOOP_1). </li>
 * <ul>
 * <ul>
 * <li> Bookmark END_LOOP pattern (eg : END_LOOP_{i}). {i} defined the i th
 * bookmark end loop (eg : END_LOOP_1). </li>
 * <ul>
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 * 
 */
public class TransformerConfig {
    
    private final static String PATTERN_BOOKMARK_PARAMETER = "\\{i\\}";
    
    public final static String START_LOOP_BOOKMARK_TYPE = "START_LOOP";

    public final static String END_LOOP_BOOKMARK_TYPE = "END_LOOP";

    public final static String IF_BOOKMARK_TYPE = "IF";

    public final static String ELSE_BOOKMARK_TYPE = "ELSE";
    
    public final static String ENDIF_BOOKMARK_TYPE = "ENDIF";

    public static String DEFAULT_IF_PATTERN = IF_BOOKMARK_TYPE + "_{i}";
    
    public static String DEFAULT_ELSE_PATTERN = ELSE_BOOKMARK_TYPE + "_{i}";

    
    public static String DEFAULT_ENDIF_PATTERN = ENDIF_BOOKMARK_TYPE + "_{i}";

    
    private String bookmarkStartLoopPattern;

    private String bookmarkEndLoopPattern;

    private String bookmarkStartLoopWithoutBookmarkParameter = null; // (eg :
                                                                        // START_LOOP_
                                                                        // if
                                                                        // pattern
                                                                        // is
                                                                        // START_LOOP_{i})

    private String bookmarkEndLoopWithoutBookmarkParameter = null; // (eg :
                                                                    // END_LOOP_
                                                                    // if
                                                                    // pattern
                                                                    // is
                                                                    // END_LOOP_{i})

    private String bookmarkIfPattern;

    private String bookmarkIfWithoutBookmarkParameter = null; // (eg : IF_ if
                                                                // pattern is
                                                                // IF_{i})
    private String bookmarkEndIfPattern;

    private String bookmarkEndIfWithoutBookmarkParameter = null; // (eg : ENDIF_ if
                                                                // pattern is
                                                                // ENDIF_{i})
    private String bookmarkElsePattern;

    private String bookmarkElseWithoutBookmarkParameter = null; // (eg : ELSE_ if
                                                                // pattern is
                                                                // ELSE_{i})
    
    public String getBookmarkStartLoopName(int index) {
        return bookmarkStartLoopPattern.replaceAll(PATTERN_BOOKMARK_PARAMETER,
                String.valueOf(index));
    }

    public String getBookmarkEndLoopName(int index) {
        return bookmarkEndLoopPattern.replaceAll(PATTERN_BOOKMARK_PARAMETER,
                String.valueOf(index));
    }

    public int getBookmarkIndex(String bookmarkName) {
        int index = -1;
        // Delete all number of bookmarkName
        String bookmarkWithoutNumber = removeNumber(bookmarkName);
        String bookmarkIndex = bookmarkName.replaceAll(bookmarkWithoutNumber,
                "");
        try {
            index = Integer.parseInt(bookmarkIndex);
        } catch (Exception e) {
        }
        ;
        return index;
    }

    public boolean isBookmarkStartLoop(String bookmarkName) {
        // Delete all number of bookmarkName
        String bookmarkWithoutNumber = removeNumber(bookmarkName);
        return bookmarkWithoutNumber
                .startsWith(getBookmarkStartLoopWithoutBookmarkParameter());
    }

    public boolean isBookmarkEndLoop(String bookmarkName) {
        // Delete all number of bookmarkName
        String bookmarkWithoutNumber = removeNumber(bookmarkName);
        return bookmarkWithoutNumber
                .startsWith(getBookmarkEndLoopWithoutBookmarkParameter());
    }

    public String getBookmarkEndLoopPattern() {
        return bookmarkEndLoopPattern;
    }

    public void setBookmarkEndLoopPattern(String bookmarkEndLoopPattern) {
        this.bookmarkEndLoopPattern = bookmarkEndLoopPattern;
    }

    public String getBookmarkStartLoopPattern() {
        return bookmarkStartLoopPattern;
    }

    public void setBookmarkStartLoopPattern(String bookmarkStartLoopPattern) {
        this.bookmarkStartLoopPattern = bookmarkStartLoopPattern;
    }

    public String getBookmarkEndLoopWithoutBookmarkParameter() {
        if (bookmarkEndLoopWithoutBookmarkParameter == null) {
            String firstBookmark = getBookmarkEndLoopName(1);
            bookmarkEndLoopWithoutBookmarkParameter = removeNumber(firstBookmark);
        }
        return bookmarkEndLoopWithoutBookmarkParameter;
    }

    public String getBookmarkStartLoopWithoutBookmarkParameter() {
        if (bookmarkStartLoopWithoutBookmarkParameter == null) {
            String firstBookmark = getBookmarkStartLoopName(1);
            bookmarkStartLoopWithoutBookmarkParameter = removeNumber(firstBookmark);
        }
        return bookmarkStartLoopWithoutBookmarkParameter;
    }

    private String removeNumber(String value) {
        return value.replaceAll("[0-9]", "");
    }

    // CONDITION IF/ELSE/ENDIF

    public String getBookmarkIfPattern() {
        if (bookmarkIfPattern == null)
            return DEFAULT_IF_PATTERN;
        return bookmarkIfPattern;
    }

    public String getBookmarkEndIfPattern() {
        if (bookmarkEndIfPattern == null)
            return DEFAULT_ENDIF_PATTERN;
        return bookmarkEndIfPattern;
    }

    public String getBookmarkElsePattern() {
        if (bookmarkElsePattern == null)
            return DEFAULT_ELSE_PATTERN;
        return bookmarkElsePattern;
    }
    
    public void setBookmarkIfPattern(String bookmarkIfPattern) {
        this.bookmarkIfPattern = bookmarkIfPattern;
    }

    public String getBookmarkIfName(int index) {
        return getBookmarkIfPattern().replaceAll(PATTERN_BOOKMARK_PARAMETER,
                String.valueOf(index));
    }

    public void setBookmarkEndIfPattern(String bookmarkEndIfPattern) {
        this.bookmarkEndIfPattern = bookmarkEndIfPattern;
    }

    public String getBookmarkEndIfName(int index) {
        return getBookmarkEndIfPattern().replaceAll(PATTERN_BOOKMARK_PARAMETER,
                String.valueOf(index));
    }
    
    public void setBookmarkElsePattern(String bookmarkElsePattern) {
        this.bookmarkElsePattern = bookmarkElsePattern;
    }

    public String getBookmarkElseName(int index) {
        return getBookmarkElsePattern().replaceAll(PATTERN_BOOKMARK_PARAMETER,
                String.valueOf(index));
    }
    
    public String getBookmarkIfWithoutBookmarkParameter() {
        if (bookmarkIfWithoutBookmarkParameter == null) {
            String firstBookmark = getBookmarkIfName(1);
            bookmarkIfWithoutBookmarkParameter = removeNumber(firstBookmark);
        }
        return bookmarkIfWithoutBookmarkParameter;
    }

    public String getBookmarkEndIfWithoutBookmarkParameter() {
        if (bookmarkEndIfWithoutBookmarkParameter == null) {
            String firstBookmark = getBookmarkEndIfName(1);
            bookmarkEndIfWithoutBookmarkParameter = removeNumber(firstBookmark);
        }
        return bookmarkEndIfWithoutBookmarkParameter;
    }

    public String getBookmarkElseWithoutBookmarkParameter() {
        if (bookmarkElseWithoutBookmarkParameter == null) {
            String firstBookmark = getBookmarkElseName(1);
            bookmarkElseWithoutBookmarkParameter = removeNumber(firstBookmark);
        }
        return bookmarkElseWithoutBookmarkParameter;
    }
    
    public boolean isBookmarkIf(String bookmarkName) {
        // Delete all number of bookmarkName
        String bookmarkWithoutNumber = removeNumber(bookmarkName);
        return bookmarkWithoutNumber
                .startsWith(getBookmarkIfWithoutBookmarkParameter());

    }

    public boolean isBookmarkEndIf(String bookmarkName) {
        // Delete all number of bookmarkName
        String bookmarkWithoutNumber = removeNumber(bookmarkName);
        return bookmarkWithoutNumber
                .startsWith(getBookmarkEndIfWithoutBookmarkParameter());

    }

    public boolean isBookmarkElse(String bookmarkName) {
        // Delete all number of bookmarkName
        String bookmarkWithoutNumber = removeNumber(bookmarkName);
        return bookmarkWithoutNumber
                .startsWith(getBookmarkElseWithoutBookmarkParameter());

    }
    
}
