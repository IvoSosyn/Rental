package net.sourceforge.rtf.document;

/**
 * 
 * RTF Annotation
 * 
 * @version 1.0.1-b14 
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 *
 */
public class RTFAnnotation extends RTFElement {

}
