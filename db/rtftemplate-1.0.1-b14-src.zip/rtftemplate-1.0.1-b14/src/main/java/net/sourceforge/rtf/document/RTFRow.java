package net.sourceforge.rtf.document;

/**
 * 
 * @version 1.0.0
 * @author <a href="mailto:angelo.zerr@gmail.com">Angelo ZERR</a>
 *
 */
public class RTFRow extends RTFElement {

	private RTFField firstField;
	
	public RTFRow() {
		
	}
	
	public RTFRow(RTFRow row) {
		super(row);
	}
	
	public void addRTFField(RTFField field) {
		if (firstField == null) {
			firstField = field;
		}
		super.addRTFElement(field);
	}
	
	public RTFField getFirstField() {
		return firstField;
	}
	
}
