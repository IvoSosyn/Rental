package net.sourceforge.rtf;

public class UnsupportedRTFDocumentTransformer extends Exception {

    public static final long serialVersionUID = 1L;
    private String rtfDocumentTransformerType;
    
    public UnsupportedRTFDocumentTransformer(String rtfDocumentTransformerType) {
        super("RTFTemplate can't support rtf document transformer type : " + rtfDocumentTransformerType);
        this.rtfDocumentTransformerType = rtfDocumentTransformerType;
    }
    
    public String getRTFDocumentTransformerType() {
        return this.rtfDocumentTransformerType;
    }

}
