package net.sourceforge.rtf.document;

public class RTFStartBookmark extends RTFBookmark {

	public RTFStartBookmark() {
		super("bkmkstart");
	}
}
